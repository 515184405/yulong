# alert
弹框组件

主体内容在alert文件夹中

文档访问地址 ： [http://fy.035k.com/project/alert](http://fy.035k.com/project/alert)
